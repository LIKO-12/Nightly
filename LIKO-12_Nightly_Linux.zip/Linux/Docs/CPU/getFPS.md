Returns the current frame per second count.

---

### Syntax:
```lua
fps = getFPS()
```

---

### Returns:

* **fps (Number)**: The FPS.