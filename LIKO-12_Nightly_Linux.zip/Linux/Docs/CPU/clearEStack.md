Clears the events stack.

---

### Syntax:
```lua
clearEStack()
```

---

##### See also:

* [pullEvent()](pullEvent.md)
* [rawPullEvent()](rawPullEvent.md)
* [triggerEvent()](triggerEvent.md)