Shutdown/exit LIKO-12

---

### Syntax
```lua
shutdown()
```

---

##### See also:

* [reboot()](reboot.md)