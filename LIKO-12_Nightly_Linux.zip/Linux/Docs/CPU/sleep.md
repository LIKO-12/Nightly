Sleeps (pauses) the current execution for specific amount of seconds.

---

### Syntax:
```lua
sleep(time)
```

---

### Arguments:

* **<time\> (Number)**: The amount of seconds to sleep.