Clears the clipboard content.

---

### Syntax:
```lua
clearClipboard()
```

---

##### See also:

* [clipboard()](clipboard.md)