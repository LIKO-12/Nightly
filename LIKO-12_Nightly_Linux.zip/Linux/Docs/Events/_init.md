This functions is called at the game start.

---

#### Syntax:
```lua
function _init()
  --Do something here
end
```