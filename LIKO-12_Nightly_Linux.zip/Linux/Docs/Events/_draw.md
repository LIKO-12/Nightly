This function is called directly after [_update()](_update.md), available to help you organize your code.

---

#### Syntax:
```lua
function _draw(dt)
  --Do something here
end
```

---

#### Arguments:

* **dt (Number)**: deltatime, the time between frames (in seconds).