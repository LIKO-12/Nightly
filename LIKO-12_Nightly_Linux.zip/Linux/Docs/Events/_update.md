Update function is called every frame, it should be used for game logic.

---

#### Syntax:
```lua
function _update(dt)
  --Do something here
end
```

---

#### Arguments:

* **dt (Number)**: deltatime, the time between frames (in seconds).