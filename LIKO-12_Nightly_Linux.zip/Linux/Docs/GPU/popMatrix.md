Pops the last cam transformations from the MatrixStack.

---

#### Syntax:
```lua
popMatrix()
```

---

##### See also:

* [pushMatrix()](pushMatrix.md)
* [clearMatrixStack()](clearMatrixStack.md)
* [cam()](cam.md)