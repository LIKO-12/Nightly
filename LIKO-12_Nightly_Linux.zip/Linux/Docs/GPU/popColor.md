Pops the last active color from the ColorStack.

---

#### Syntax:
```lua
popColor()
```

---

##### See also:

* [pushColor()](pushColor.md)
* [color()](color.md)
* [colorPalette()](colorPalette.md)