Returns the image width.

---

#### Syntax:
```lua
w = img:width() --Dont's forget the ':'
```

---

#### Returns:

* **w (Number)**: The image width in pixels.