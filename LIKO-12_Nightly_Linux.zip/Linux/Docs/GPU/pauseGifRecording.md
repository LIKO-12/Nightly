Pause LIKO-12 screen Gif recording by code.

---

#### Syntax:

---

```lua
pauseGifRecording()
```


---

##### See also:

* [startGifRecording()](startGifRecording.md)
* [endGifRecording()](endGifRecording.md)
* [isGifRecording()](isGifRecording.md)