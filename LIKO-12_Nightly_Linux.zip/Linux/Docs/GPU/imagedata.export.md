Exports the imagedata to png, all transparent pixel in [palt()](palt.md) will be transparent in the result png.

---

#### Syntax:
```lua
png = imgdata:export()
```

---

#### Returns:

* **png (String)**: The binary png data.