Gets the type of the object as a string.

---

#### Syntax:
```lua
t = imgdata:type() --Don't forget the ':'
```

---

#### Returns:

* **t (String)**: The object type, "GPU.imageData".