Returns the imagedata dimensions.

---

#### Syntax:
```lua
w,h = imgdata:size() --Dont's forget the ':'
```

---

#### Returns:

* **w (Number)**: The imagedata width in pixels.
* **h (Number)**: The imagedata height in pixels.