Pop the last color mapping and transparent colors list from the palettes stack.

---

#### Syntax:
```lua
popPalette()
```