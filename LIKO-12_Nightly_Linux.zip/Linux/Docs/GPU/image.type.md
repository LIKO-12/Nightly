Gets the type of the object as a string.

---

#### Syntax:
```lua
t = img:type() --Don't forget the ':'
```

---

#### Returns:

* **t (String)**: The object type, "GPU.image".