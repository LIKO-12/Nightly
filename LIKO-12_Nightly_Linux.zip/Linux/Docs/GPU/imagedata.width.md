Returns the imagedata width.

---

#### Syntax:
```lua
w = imgdata:width() --Dont's forget the ':'
```

---

#### Returns:

* **w (Number)**: The imagedata width in pixels.