Encodes the imagedata into [LK12 GPU Image](../Files Format/GPU Image.md) string.

---

#### Syntax:
```lua
data = imgdata:encode()
```

---

#### Returns:

* **data (String)**: The imagedata [LK12 GPU Image](../Files Format/GPU Image.md) string.