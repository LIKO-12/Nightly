Returns the image dimensions.

---

#### Syntax:
```lua
w,h = img:size() --Dont's forget the ':'
```

---

#### Returns:

* **w (Number)**: The image width in pixels.
* **h (Number)**: The image height in pixels.