Pushes the current color mapping and transparent colors list to the palettes stack.

---

#### Syntax:
```lua
pushPalette()
```

---

##### See also:

* [popPalette()](popPalette.md)
* [pal()](pal.md)
* [palt()](palt.md)