Pushes the current active color to the ColorStack.

---

#### Syntax:
```lua
pushColor()
```

---

##### See also:

* [popColor()](popColor.md)
* [color()](color.md)
* [colorPalette()](colorPalette.md)