End LIKO-12 screen Gif recording by code.

---

#### Syntax:

---

```lua
endGifRecording()
```

---

##### See also:

* [startGifRecording()](startGifRecording.md)
* [pauseGifRecording()](pauseGifRecording.md)
* [isGifRecording()](isGifRecording.md)