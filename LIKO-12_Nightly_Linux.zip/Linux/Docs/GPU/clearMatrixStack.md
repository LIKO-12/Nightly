Clears the matrix stack (By doing [popMatrix()](popMatrix.md))

---

#### Syntax:

---

```lua
clearMatrixStack.md
```

---

##### See also:

* [pushMatrix](pushMatrix.md)
* [popMatrix](popMatrix.md)