Returns the imagedata height.

---

#### Syntax:
```lua
h = imgdata:height() --Dont's forget the ':'
```

---

#### Returns:

* **h (Number)**: The imagedata height in pixels.