Reloads the Image's contents from the ImageData used to create the image.

---

#### Syntax:
```lua
img:refresh() --Don't forget the ':'
```
---

##### See also:

* [imagedata:image()](imagedata.image.md)