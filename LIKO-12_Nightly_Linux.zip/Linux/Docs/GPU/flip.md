Waits till the screen is applied and shown to the user, helpful when doing some loading operations.

---

#### Syntax:
```lua
flip()
```