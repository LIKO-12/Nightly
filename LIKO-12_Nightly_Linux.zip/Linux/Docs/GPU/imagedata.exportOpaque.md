Exports the imagedata to png, all the colors will be opaque.

---

#### Syntax:
```lua
png = imgdata:export()
```

---

#### Returns:

* **png (String)**: The binary png data.