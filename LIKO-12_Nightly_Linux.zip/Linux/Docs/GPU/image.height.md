Returns the image height.

---

#### Syntax:
```lua
h = img:height() --Dont's forget the ':'
```

---

#### Returns:

* **h (Number)**: The image height in pixels.