Start LIKO-12 screen Gif recording by code.

---

#### Syntax:

---

```lua
startGifRecording()
```

---

##### See also:

* [pauseGifRecording()](pauseGifRecording.md)
* [endGifRecording()](endGifRecording.md)
* [isGifRecording()](isGifRecording.md)