![GPU Cheatsheet](https://github.com/RamiLego4Game/LIKO-12/raw/master/Extra/Cheatsheets/GPU/LIKO-12%20GPU%20Cheatsheet.png)

---

### Downloads:

---

* **PNG Image**: [Download from Github](https://github.com/RamiLego4Game/LIKO-12/raw/master/Extra/Cheatsheets/GPU/LIKO-12%20GPU%20Cheatsheet.png)
* **PDF Document**: [Download from Github](https://github.com/RamiLego4Game/LIKO-12/raw/master/Extra/Cheatsheets/GPU/LIKO-12%20GPU%20Cheatsheet.pdf)
* **Source Inkscape SVG**: [Download from Github](https://github.com/RamiLego4Game/LIKO-12/raw/master/Extra/Cheatsheets/GPU/LIKO-12%20GPU%20Cheatsheet.svg)

---

### License:

---

This cheatsheet is licensed under [CC-BY 4.0](https://creativecommons.org/licenses/by/4.0/).

![CC-BY Budget Image](https://licensebuttons.net/l/by/3.0/88x31.png)