The values passed to the mouse events:

---

* **1 (Number)**: Left mouse button.
* **2 (Number)**: Right mouse button.
* **3 (Number)**: Middle mouse button.