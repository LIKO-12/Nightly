Returns true if a file or directory exists.

**Important: This function is only available in the operating system programs!**

---

### Syntax:
```lua
existent = fs.exists("/test.txt")
```

---

### Returns:

* **existent (Boolean)**: Existence of file or directory
