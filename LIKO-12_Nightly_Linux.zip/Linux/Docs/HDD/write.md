Writes content to a file (Will override anything in the file).

**Important: This function is only available in the operating system programs!**

---

### Syntax:
```lua
 fs.write("/file.txt", "text")
```
