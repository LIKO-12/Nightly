Returns true if the path given represents a directory.

**Important: This function is only available in the operating system programs!**

---

### Syntax:
```lua
dir = fs.isDirectory("/file.txt")
```

---

### Returns:

* **file (Boolean)**: Is path representing a directory?
