Deletes a file.

**Important: This function is only available in the operating system programs!**

---

### Syntax:
```lua
fs.delete("/file.txt")
```
