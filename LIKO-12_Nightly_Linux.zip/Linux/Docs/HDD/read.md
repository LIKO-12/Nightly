Returns the content of a file.

**Important: This function is only available in the operating system programs!**

---

### Syntax:
```lua
data = fs.read("/file.txt")
```

---

### Returns:
* **data (String)**: The content of the file.