Appends content to the end of a file.

**Important: This function is only available in the operating system programs!**

---

### Syntax:
```lua
fs.append("/file.txt", "text")
```
