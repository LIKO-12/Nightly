Returns true if the path given represents a file.

**Important: This function is only available in the operating system programs!**

---

### Syntax:
```lua
file = fs.isFile("/file.txt")
```

---

### Returns:

* **file (Boolean)**: Is path representing a file?
