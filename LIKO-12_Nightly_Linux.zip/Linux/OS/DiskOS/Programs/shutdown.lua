if select(1,...) == "-?" then
  printUsage(
    "shutdown","Shutdowns LIKO-12"
  )
  return
end
shutdown()