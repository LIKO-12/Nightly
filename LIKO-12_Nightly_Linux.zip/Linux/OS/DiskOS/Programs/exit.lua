if select(1,...) == "-?" then
  printUsage(
    "exit","Exits LIKO-12"
  )
  return
end
shutdown()
