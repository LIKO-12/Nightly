Pushes the current active color to the ColorStack.

---

#### Syntax:
```lua
pushColor()
```