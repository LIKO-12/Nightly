Pops the last active color from the ColorStack.

---

#### Syntax:
```lua
popColor()
```