Pushes the current color mapping and transparent colors list to the palettes stack.

---

#### Syntax:
```lua
pushPalette()
```