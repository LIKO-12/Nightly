--Text Utilities.

--Variables.


--Localized Lua Library


--The API
local TextUtils = {}

--Make the textutils a global
_G["TextUtils"] = TextUtils