--Disk File (.lk12) Utilities.

--Variables.


--Localized Lua Library


--The API
local DiskUtils = {}

function DiskUtils.save(ctype,clvl)
  
end

function DiskUtils.write()
  
end

--Make the diskutils a global
_G["DiskUtils"] = DiskUtils