--Native Builds Utilities.

--Variables.


--Localized Lua Library


--The API
local BuildUtils = {}

--Make the buildutils a global
_G["BuildUtils"] = BuildUtils